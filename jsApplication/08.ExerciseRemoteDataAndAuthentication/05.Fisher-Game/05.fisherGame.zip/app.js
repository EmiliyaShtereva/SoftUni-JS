let main = document.querySelector('main');
let homeBtn = document.getElementById('home');
let logoutBtn = document.getElementById('logout');
let guestBtns = document.getElementById('guest');
let loginBtn = document.getElementById('login');
let registerBtn = document.getElementById('register');
let homeView = document.getElementById('home-view');
let loginView = document.getElementById('login-view');
let registerViel = document.getElementById('register-view');
const addButtonElem = document.getElementsByClassName("add")[0];
const addFormElem = document.getElementById("addForm");
const catchesDivElem = document.getElementById("catches");
const loadButtonElem = document.getElementsByClassName("load")[0];

window.addEventListener('load', loadPage);

function loadPage() {
    loginView.style.display = 'none';
    registerViel.style.display = 'none';

    let accessToken = sessionStorage.getItem('accessToken');
    const loggedUserEmail = sessionStorage.getItem("loggedUser");

    main.appendChild(homeView);
    homeView.style.display = 'inline';
    Array.from(catchesDivElem.children).forEach((child) => child.remove());

    if (accessToken == undefined) {
        guestBtns.style.display = 'inline';
        logoutBtn.style.display = 'none';
        addButtonElem.disabled = true;
        document.querySelector("span").textContent = "guest";
    } else {
        guestBtns.style.display = 'none';
        logoutBtn.style.display = 'inline';
        addButtonElem.disabled = false;
        document.querySelector("span").textContent = loggedUserEmail;
    }

    loginBtn.addEventListener('click', loginHandler);
    registerBtn.addEventListener('click', registerHandler);
    logoutBtn.addEventListener('click', logout);
    addButtonElem.addEventListener("click", onAdd);
    loadButtonElem.addEventListener("click", onLoad);
}


async function loginHandler() {
    loginView.style.display = 'inline-block';
    let form = document.querySelector('form[id="login"]');

    main.appendChild(loginView);
    homeView.style.display = 'none';
    form.addEventListener('submit', login);

    async function login(e) {
        e.preventDefault();

        let formData = new FormData(form);
        let notification = document.getElementsByClassName("notification")[0];
        const email = formData.get("email");
        const password = formData.get("password");

        if (!email) {
            notification.textContent = "Email is required!";
        } else if (!password) {
            notification.textContent = "Password is required!";
        }

        if (email && password) {
            let url = 'http://localhost:3030/users/login';
            let settings = {
                method: 'Post',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: email,
                    password: password
                })
            };

            let response = await fetch(url, settings);
            try {
                if (response.status === 200) {
                    let result = await response.json();

                    sessionStorage.setItem('accessToken', result.accessToken);
                    sessionStorage.setItem("loggedUser", result.email);
                    sessionStorage.setItem("id", result._id);
                    loadPage();
                } else {
                    let jsonResponse = await response.json();
                    throw new Error(jsonResponse.message);
                }
            } catch (e) {
                notification.textContent = e.message;
            }
        }
    }
}

async function registerHandler() {
    registerViel.style.display = 'inline-block';
    let form = document.querySelector('form[id="register"]');

    main.appendChild(registerViel);
    homeView.style.display = 'none';
    form.addEventListener('submit', register);

    async function register(e) {
        e.preventDefault();

        let formData = new FormData(form);
        let notification = document.getElementsByClassName("notification")[0];
        const email = formData.get("email");
        const password = formData.get("password");
        const repeat = formData.get("rePass");

        if (!email) {
            notification.textContent = "Email is required!";
        } else if (!password) {
            notification.textContent = "Password is required!";
        } else if (!repeat) {
            notification.textContent = "Repeat is required!";
        } else if (password !== repeat) {
            return notification.textContent = "Password and Repeat have to be the same!";
        }

        if (email && password && repeat) {
            let url = 'http://localhost:3030/users/register';
            let settings = {
                method: 'Post',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: email,
                    password: password
                })
            };

            let response = await fetch(url, settings);
            try {
                if (response.status === 200) {
                    let result = await response.json();

                    sessionStorage.setItem('accessToken', result.accessToken);
                    sessionStorage.setItem("loggedUser", result.email);
                    sessionStorage.setItem("id", result._id);
                    loadPage();
                } else {
                    let jsonResponse = await response.json();
                    throw new Error(jsonResponse.message);
                }
            } catch (e) {
                notification.textContent = e.message;
            }
        }
    }
}

async function logout() {
    let url = 'http://localhost:3030/users/logout';
    let settings = {
        method: 'Get',
        headers: {
            'X-Authorization': sessionStorage.getItem('accessToken')
        }
    };

    let response = await fetch(url, settings);

    if (response.status === 204) {
        sessionStorage.removeItem('accessToken');
        sessionStorage.removeItem("accessToken");
        sessionStorage.removeItem("loggedUser");
        loadPage();
    }
}

async function onLoad() {
    Array.from(catchesDivElem.children).forEach((child) => child.remove());

    const response = await fetch("http://localhost:3030/data/catches");
    let catches = await response.json();

    // for each catch => create "catch HTML content" => add this HTML to the page
    for (const currentCatch of catches) {
        const catchDivElem = createElements("div", "", catchesDivElem, {
            class: "catch",
        });

        createElements("label", "Angler", catchDivElem, {});
        createElements("input", "", catchDivElem, {
            type: "text",
            class: "angler",
            value: currentCatch.angler,
        });
        createElements("label", "Weight", catchDivElem, {});
        createElements("input", "", catchDivElem, {
            type: "text",
            class: "weight",
            value: currentCatch.weight,
        });
        createElements("label", "Species", catchDivElem, {});
        createElements("input", "", catchDivElem, {
            type: "text",
            class: "species",
            value: currentCatch.species,
        });
        createElements("label", "Location", catchDivElem, {});
        createElements("input", "", catchDivElem, {
            type: "text",
            class: "location",
            value: currentCatch.location,
        });
        createElements("label", "Bait", catchDivElem, {});
        createElements("input", "", catchDivElem, {
            type: "text",
            class: "bait",
            value: currentCatch.bait,
        });
        createElements("label", "Capture Time", catchDivElem, {});
        createElements("input", "", catchDivElem, {
            type: "text",
            class: "captureTime",
            value: currentCatch.captureTime,
        });

        const updateBtnElem = createElements("button", "Update", catchDivElem, {
            class: "update",
            "data-id": currentCatch._id,
        });

        const deleteBtnElem = createElements("button", "Delete", catchDivElem, {
            class: "delete",
            "data-id": currentCatch._id,
        });

        const loggedUserId = sessionStorage.getItem("id");

        if (loggedUserId !== currentCatch._ownerId) {
            updateBtnElem.disabled = true;
            deleteBtnElem.disabled = true;
        }

        updateBtnElem.addEventListener("click", onUpdate);
        deleteBtnElem.addEventListener("click", onDelete);
    }
}

async function onUpdate(event) {
    event.preventDefault();
    const catchDivElem = event.target.parentElement;
    const angler = catchDivElem.getElementsByClassName("angler")[0].value.trim();
    const weight = catchDivElem.getElementsByClassName("weight")[0].value.trim();
    const species = catchDivElem.getElementsByClassName("species")[0].value.trim();
    const location = catchDivElem.getElementsByClassName("location")[0].value.trim();
    const bait = catchDivElem.getElementsByClassName("bait")[0].value.trim();
    const captureTime = catchDivElem.getElementsByClassName("captureTime")[0].value.trim();

    if (!angler) {
        alert("angler is required!");
    } else if (!weight) {
        alert("weight is required!");
    } else if (!species) {
        alert("species is required!");
    } else if (!location) {
        alert("location is required!");
    } else if (!bait) {
        alert("bait is required!");
    } else if (!captureTime) {
        alert("captureTime is required!");
    }

    let accessToken = sessionStorage.getItem('accessToken');
    if (angler && weight && species && location && bait && captureTime) {
        try {
            const response = await fetch(
                `http://localhost:3030/data/catches/${event.target.dataset.id}`,
                {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        "X-Authorization": accessToken,
                    },
                    body: JSON.stringify({
                        angler,
                        weight,
                        species,
                        location,
                        bait,
                        captureTime,
                    }),
                }
            );

            if (!response.ok) {
                throw new Error(response.statusText);
            }

            await onLoad();
        } catch (err) {
            alert(err.message);
        }
    }
}

async function onDelete(event) {
    let accessToken = sessionStorage.getItem('accessToken');
    const response = await fetch(
        `http://localhost:3030/data/catches/${event.target.dataset.id}`,
        {
            method: "DELETE",
            headers: {
                "X-Authorization": accessToken,
            },
        }
    );

    if (!response.ok) {
        throw new Error(response.statusText);
    } else {
        await onLoad();
    }
}

async function onAdd(event) {
    event.preventDefault();

    const formData = new FormData(addFormElem);
    const angler = formData.get("angler");
    const weight = formData.get("weight");
    const species = formData.get("species");
    const location = formData.get("location");
    const bait = formData.get("bait");
    const captureTime = formData.get("captureTime");

    if (!angler) {
        alert("angler is required!");
    } else if (!weight) {
        alert("weight is required!");
    } else if (!species) {
        alert("species is required!");
    } else if (!location) {
        alert("location is required!");
    } else if (!bait) {
        alert("bait is required!");
    } else if (!captureTime) {
        alert("captureTime is required!");
    }

    let accessToken = sessionStorage.getItem('accessToken');
    if (angler && weight && species && location && bait && captureTime) {
        try {
            const response = await fetch("http://localhost:3030/data/catches", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Authorization": accessToken,
                },
                body: JSON.stringify({
                    angler,
                    weight,
                    species,
                    location,
                    bait,
                    captureTime,
                }),
            });

            if (!response.ok) {
                throw new Error(response.statusText);
            }

            Array.from(addFormElem.querySelectorAll("input")).forEach(
                (input) => (input.value = "")
            );

            await onLoad();
        } catch (err) {
            alert(err.message);
        }
    }
}

function createElements(type, content, parent, attributes) {
    const elem = document.createElement(type);
    elem.textContent = content;

    if (parent) {
        parent.appendChild(elem);
    }

    for (const [attribute, value] of Object.entries(attributes)) {
        elem.setAttribute(attribute, value);
    }

    return elem;
}